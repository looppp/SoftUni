import java.util.Scanner;

public class HousePattern {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int houseSize = Integer.parseInt(sc.nextLine());


    }
}
