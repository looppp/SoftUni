function largerOfTwo(firstNumber, secondNumber) {
  console.log(Math.max(firstNumber, secondNumber));
}

largerOfTwo(3, 55);
