function evenOrOdd(number) {
  if (number % 2 == 0) {
    console.log("even");
  } else {
    console.log("odd");
  }
}

evenOrOdd(3);
