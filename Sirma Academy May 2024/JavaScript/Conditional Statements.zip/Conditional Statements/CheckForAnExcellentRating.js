function isExcellent(grade) {
  if (grade >= 5.5) {
    console.log("Excellent");
  } else {
    console.log("no output");
  }
}

isExcellent(5.4);
