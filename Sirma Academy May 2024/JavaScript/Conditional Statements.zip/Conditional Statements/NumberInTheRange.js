function numberInRange(number) {
  if (number >= -100 && number <= 100) {
    console.log("Yes");
  } else {
    console.log("No");
  }
}

numberInRange(-252);
